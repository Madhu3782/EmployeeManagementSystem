import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JDBC2 {
    private JFrame frame;
    private JTable employeeTable;
    private EmployeeTableModel tableModel;
    private Connection connection;

    // Database connection details
    // Change to use environment variables or configuration
    private static final String DB_URL = System.getenv("DB_URL");
    private static final String DB_USER = System.getenv("DB_USER");
    private static final String DB_PASSWORD = System.getenv("DB_PASSWORD");

    public JDBC2() {
        initialize();
        connectToDatabase();
        refreshEmployeeData();
    }

    private void initialize() {
        frame = new JFrame("Employee Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());

        // Create menu bar
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitMenuItem);
        menuBar.add(fileMenu);
        frame.setJMenuBar(menuBar);

        // Create buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        JButton createButton = new JButton("Create");
        createButton.addActionListener(e -> showCreateDialog());
        buttonPanel.add(createButton);

        JButton readButton = new JButton("Refresh");
        readButton.addActionListener(e -> refreshEmployeeData());
        buttonPanel.add(readButton);

        JButton updateButton = new JButton("Update");
        updateButton.addActionListener(e -> showUpdateDialog());
        buttonPanel.add(updateButton);

        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(e -> deleteSelectedEmployee());
        buttonPanel.add(deleteButton);

        frame.add(buttonPanel, BorderLayout.NORTH);

        // Create table
        tableModel = new EmployeeTableModel();
        employeeTable = new JTable(tableModel);
        employeeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(employeeTable);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Status bar
        JLabel statusLabel = new JLabel("Ready");
        frame.add(statusLabel, BorderLayout.SOUTH);

        frame.setVisible(true);
    }

    private void connectToDatabase() {
        try {
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Database connection failed: " + e.getMessage(),
                    "Connection Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }

    private void refreshEmployeeData() {
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Employees")) {

            List<Employee> employees = new ArrayList<>();
            while (rs.next()) {
                Employee emp = new Employee(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("address"),
                        rs.getDouble("salary"),
                        rs.getInt("age"),
                        rs.getDate("dob")
                );
                employees.add(emp);
            }
            tableModel.setEmployees(employees);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error loading employee data: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showCreateDialog() {
        JDialog dialog = new JDialog(frame, "Create New Employee", true);
        dialog.setSize(400, 300);
        dialog.setLayout(new GridLayout(7, 2));

        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField addressField = new JTextField();
        JTextField salaryField = new JTextField();
        JTextField ageField = new JTextField();
        JTextField dobField = new JTextField();

        dialog.add(new JLabel("ID:"));
        dialog.add(idField);
        dialog.add(new JLabel("Name:"));
        dialog.add(nameField);
        dialog.add(new JLabel("Address:"));
        dialog.add(addressField);
        dialog.add(new JLabel("Salary:"));
        dialog.add(salaryField);
        dialog.add(new JLabel("Age:"));
        dialog.add(ageField);
        dialog.add(new JLabel("Date of Birth (YYYY-MM-DD):"));
        dialog.add(dobField);

        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                String name = nameField.getText();
                String address = addressField.getText();
                double salary = Double.parseDouble(salaryField.getText());
                int age = Integer.parseInt(ageField.getText());
                Date dob = Date.valueOf(dobField.getText());

                // Check if ID exists
                try (PreparedStatement checkStmt = connection.prepareStatement(
                        "SELECT 1 FROM Employees WHERE id = ?")) {
                    checkStmt.setInt(1, id);
                    ResultSet rs = checkStmt.executeQuery();
                    if (rs.next()) {
                        JOptionPane.showMessageDialog(dialog, "Employee ID " + id + " already exists!",
                                "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                // Insert new employee
                try (PreparedStatement pstmt = connection.prepareStatement(
                        "INSERT INTO Employees VALUES (?, ?, ?, ?, ?, ?)")) {
                    pstmt.setInt(1, id);
                    pstmt.setString(2, name);
                    pstmt.setString(3, address);
                    pstmt.setDouble(4, salary);
                    pstmt.setInt(5, age);
                    pstmt.setDate(6, dob);

                    pstmt.executeUpdate();
                    JOptionPane.showMessageDialog(dialog, "Employee added successfully!");
                    dialog.dispose();
                    refreshEmployeeData();
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage(),
                        "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> dialog.dispose());

        dialog.add(saveButton);
        dialog.add(cancelButton);

        dialog.setVisible(true);
    }

    private void showUpdateDialog() {
        int selectedRow = employeeTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(frame, "Please select an employee to update",
                    "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Employee selectedEmployee = tableModel.getEmployeeAt(selectedRow);
        JDialog dialog = new JDialog(frame, "Update Employee", true);
        dialog.setSize(400, 300);
        dialog.setLayout(new GridLayout(7, 2));

        JTextField idField = new JTextField(String.valueOf(selectedEmployee.getId()));
        idField.setEditable(false);
        JTextField nameField = new JTextField(selectedEmployee.getName());
        JTextField addressField = new JTextField(selectedEmployee.getAddress());
        JTextField salaryField = new JTextField(String.valueOf(selectedEmployee.getSalary()));
        JTextField ageField = new JTextField(String.valueOf(selectedEmployee.getAge()));
        JTextField dobField = new JTextField(selectedEmployee.getDob().toString());

        dialog.add(new JLabel("ID:"));
        dialog.add(idField);
        dialog.add(new JLabel("Name:"));
        dialog.add(nameField);
        dialog.add(new JLabel("Address:"));
        dialog.add(addressField);
        dialog.add(new JLabel("Salary:"));
        dialog.add(salaryField);
        dialog.add(new JLabel("Age:"));
        dialog.add(ageField);
        dialog.add(new JLabel("Date of Birth (YYYY-MM-DD):"));
        dialog.add(dobField);

        JButton updateButton = new JButton("Update");
        updateButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                String name = nameField.getText();
                String address = addressField.getText();
                double salary = Double.parseDouble(salaryField.getText());
                int age = Integer.parseInt(ageField.getText());
                Date dob = Date.valueOf(dobField.getText());

                try (PreparedStatement pstmt = connection.prepareStatement(
                        "UPDATE Employees SET name = ?, address = ?, salary = ?, age = ?, dob = ? WHERE id = ?")) {
                    pstmt.setString(1, name);
                    pstmt.setString(2, address);
                    pstmt.setDouble(3, salary);
                    pstmt.setInt(4, age);
                    pstmt.setDate(5, dob);
                    pstmt.setInt(6, id);

                    int rowsAffected = pstmt.executeUpdate();
                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(dialog, "Employee updated successfully!");
                        dialog.dispose();
                        refreshEmployeeData();
                    }
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage(),
                        "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> dialog.dispose());

        dialog.add(updateButton);
        dialog.add(cancelButton);

        dialog.setVisible(true);
    }

    private void deleteSelectedEmployee() {
        int selectedRow = employeeTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(frame, "Please select an employee to delete",
                    "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Employee selectedEmployee = tableModel.getEmployeeAt(selectedRow);
        int confirm = JOptionPane.showConfirmDialog(frame,
                "Are you sure you want to delete employee " + selectedEmployee.getName() + "?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (PreparedStatement pstmt = connection.prepareStatement(
                    "DELETE FROM Employees WHERE id = ?")) {
                pstmt.setInt(1, selectedEmployee.getId());
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(frame, "Employee deleted successfully!");
                    refreshEmployeeData();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(frame, "Error deleting employee: " + e.getMessage(),
                        "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new JDBC2();
        });
    }
}

class Employee {
    private int id;
    private String name;
    private String address;
    private double salary;
    private int age;
    private Date dob;

    public Employee(int id, String name, String address, double salary, int age, Date dob) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.salary = salary;
        this.age = age;
        this.dob = dob;
    }

    // Getters
    public int getId() { return id; }
    public String getName() { return name; }
    public String getAddress() { return address; }
    public double getSalary() { return salary; }
    public int getAge() { return age; }
    public Date getDob() { return dob; }
}

class EmployeeTableModel extends javax.swing.table.AbstractTableModel {
    private List<Employee> employees = new ArrayList<>();
    private String[] columnNames = {"ID", "Name", "Address", "Salary", "Age", "Date of Birth"};

    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
        fireTableDataChanged();
    }

    public Employee getEmployeeAt(int row) {
        return employees.get(row);
    }

    @Override
    public int getRowCount() {
        return employees.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Employee employee = employees.get(rowIndex);
        switch (columnIndex) {
            case 0: return employee.getId();
            case 1: return employee.getName();
            case 2: return employee.getAddress();
            case 3: return employee.getSalary();
            case 4: return employee.getAge();
            case 5: return employee.getDob();
            default: return null;
        }
    }
}